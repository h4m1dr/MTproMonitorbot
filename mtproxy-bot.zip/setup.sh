#!/usr/bin/env bash
set -e

# Basic colors
GREEN="\033[32m"
YELLOW="\033[33m"
RESET="\033[0m"

echo -e "${GREEN}[*] Detecting OS and installing prerequisites...${RESET}"

if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y python3 python3-venv python3-pip curl
elif command -v yum >/dev/null 2>&1; then
  sudo yum install -y python3 python3-venv python3-pip curl
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Create venv
if [ ! -d "venv" ]; then
  python3 -m venv venv
fi
source venv/bin/activate

# Requirements
cat > requirements.txt <<EOF
python-telegram-bot==21.6
python-dotenv
EOF

pip install -r requirements.txt

# Ask for basic env
ENV_FILE=".env"
if [ ! -f "$ENV_FILE" ]; then
  echo -e "${YELLOW}[?] Enter bot token:${RESET}"
  read -r BOT_TOKEN
  echo -e "${YELLOW}[?] Enter owner Telegram ID:${RESET}"
  read -r OWNER_ID
  echo -e "${YELLOW}[?] Enter MTProxy service name (default MTProxy):${RESET}"
  read -r SERVICE_NAME
  SERVICE_NAME=${SERVICE_NAME:-MTProxy}

  echo "BOT_TOKEN=$BOT_TOKEN" > "$ENV_FILE"
  echo "OWNER_ID=$OWNER_ID" >> "$ENV_FILE"
  echo "ADMIN_IDS=$OWNER_ID" >> "$ENV_FILE"
  echo "MTPROXY_SERVICE_NAME=$SERVICE_NAME" >> "$ENV_FILE"
  echo "MTPROXY_PORT=443" >> "$ENV_FILE"
  echo "MTPROXY_TLS_DOMAIN=" >> "$ENV_FILE"
  echo "DB_PATH=./data/mtproxy-bot.db" >> "$ENV_FILE"
fi

mkdir -p data

# Optionally install MTProxy if not installed (stub)
if ! systemctl list-unit-files | grep -q "MTProxy.service"; then
  echo -e "${YELLOW}[!] MTProxy.service not found. You should install MTProxy first (official script).${RESET}"
  # Here you can integrate official MTProxy installer script
fi

# Create systemd service for bot
SERVICE_FILE="/etc/systemd/system/mtproxy-bot.service"
sudo bash -c "cat > $SERVICE_FILE" <<EOF
[Unit]
Description=MTProxy Manager Telegram Bot
After=network.target

[Service]
Type=simple
WorkingDirectory=$SCRIPT_DIR
ExecStart=$SCRIPT_DIR/venv/bin/python -m bot.bot
Restart=always
User=$USER
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable mtproxy-bot
sudo systemctl restart mtproxy-bot

echo -e "${GREEN}[+] mtproxy-bot service is running.${RESET}"
